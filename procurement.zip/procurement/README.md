

The app analyses data that contains information about prospective partners.
Data includes a list of companies with information about industries, corporate credit score, relevant experience, company size and corporate reputation.
Algorithm takes parameters as an input and predict whether the company qualifies as a potential supplier.
	

Installation Requirements:
react-native-cli@2.0.1
yarn@1.22.19

1. Check installed software:
    npm list -global --depth 0
Install NodeJs. -> To check version type: "node -v".
If yarn not istalled type: 
    yarn install 
    yarn start
2. Open new terminal window:
 Change directory to the folder with the Main file.
    cd ~/**/api
    python main.py

