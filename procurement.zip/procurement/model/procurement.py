import pandas as pd
import numpy as np

df = pd.read_csv('procurement.csv')

# Downscalling Method For CRR & CCR grades
def downscale(score):
    return score/10/2

ratings = ['crr', 'ccr']

for col in ratings:
    df[col] = downscale(df[col])

    
# Separating into dependent and independent variables
X = df.drop(['converted'], axis=1)
y = df.converted

    
# Splitting df into trainig and testing
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y,train_size=0.8,random_state=1)

# Fitting with random forest model
from sklearn.ensemble import RandomForestClassifier
model=RandomForestClassifier(n_estimators=100)
model.fit(X_train,y_train)

# Prediction and testing
y_pred=model.predict(X_test)

# Report and Accuracy Score
from sklearn import metrics
from sklearn.metrics import classification_report
print("Accuracy:",metrics.accuracy_score(y_test, y_pred))
print("Classification Report RF:\n",classification_report(y_test,y_pred))


sample = np.array([[4, 2.9, 1, 112, 3.7]])
model.predict(sample)

# Saving model
import pickle
pickle.dump(model, open('procurement.pkl', 'wb'))

# Loading model
loaded_model = pickle.load(open('procurement.pkl', 'rb'))
result = loaded_model.score(X_test, y_test)
print(result)
