import './Glass.css'
import { useState } from 'react'
import axios from 'axios'

function Glass() {
  const [industry, setIndustry] = useState('')
  const [crr, setCrr] = useState('')
  const [experience, setExperience] = useState('')
  const [company_size, setCompany_size] = useState('')
  const [ccr, setCcr] = useState('')


  const handleSubmit = (e) => {
    e.preventDefault()
    const params = { industry, crr, experience, company_size, ccr }

    axios
      .post('http://localhost:8080/prediction', params)
      .then((res) => {
        const data = res.data.data
        const parameters = JSON.stringify(params)
        const msg = `Automated Prediction: ${data.prediction}\n Data Interpretation: ${data.interpretation}\n Input Data: ${parameters}`
        alert(msg)
        reset()
      })
      .catch((error) => alert(`Error: ${error.message}`))
  }

  const reset = () => {
    setIndustry('')
    setCrr('')
    setExperience('')
    setCompany_size('')
    setCcr('')
  }

  return (
    <div className="glass">
      <form onSubmit={(e) => handleSubmit(e)} className="glass__form">
        <h4>Supplier Data</h4>
        <div className="glass__form__group">
          <input
            id="industry"
            className="glass__form__input"
            placeholder="Industry (1 = Telecom, 2 = Finance, 3 = Real Estate, 4 = IT"
            required
            autoFocus
            min="0"
            max="4"
            pattern="[0-9]{0,1,2,3,4}"
            title="industry must be defined"
            type="number"
            value={industry}
            onChange={(e) => setIndustry(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="crr"
            className="glass__form__input"
            placeholder="Corporate Credit Rating (1.00 - 5.00)"
            required
            min="0"
            max="5"
            type="number"
            title="Corporate Crerit Rating must be defined"
            pattern="[0-9]+([\.,][0-9]+)?"
            step="0.01"
            value={crr}
            onChange={(e) => setCrr(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="experience"
            className="glass__form__input"
            placeholder="Relevant Experience  (1 = True or 0 = False)"
            required
            min="0"
            max="1"
            type="number"
            title="Relevant Experience must be defined"
            value={experience}
            onChange={(e) => setExperience(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="company_size"
            className="glass__form__input"
            placeholder="Company Size in range (1- 100)"
            required
            min="0"
            max="100"
            type="number"
            title="Company Size must be defined"
            pattern="[0-9]+([\.,][0-9]+)?"
            step="1"
            value={company_size}
            onChange={(e) => setCompany_size(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="ccr"
            className="glass__form__input"
            placeholder="Corporate Reputation Rating (1.00 - 5.00)"
            required
            min="0"
            max="5"
            type="number"
            title="Corporate Reputation Rating must be defined"
            pattern="[0-9]+([\.,][0-9]+)?"
            step="0.01"
            value={ccr}
            onChange={(e) => setCcr(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <button type="submit" className="glass__form__btn">
            Submit
          </button>
        </div>
      </form>
    </div>
  )
}

export default Glass
