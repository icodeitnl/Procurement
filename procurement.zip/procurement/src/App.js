import './App.css';
import Glass from './components/Glass'

function App() {
  return (
    <div className="app">
      <Glass/>
    </div>
  );
}

export default App;
